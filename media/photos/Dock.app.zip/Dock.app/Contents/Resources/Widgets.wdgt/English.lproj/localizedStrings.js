var localizedStrings = new Array;

localizedStrings['Uncheck Widgets to disable them.'] = 'Uncheck Widgets to disable them.';
localizedStrings['Sort by Name'] = 'Sort by Name';
localizedStrings['Sort by Date'] = 'Sort by Date';
localizedStrings['Sort by Enabled'] = 'Sort by Enabled';
localizedStrings['enabled'] = 'enabled';
localizedStrings['disabled'] = 'disabled';
localizedStrings['More Widgets…'] = 'More Widgets…';
localizedStrings['Move this widget to the Trash?'] = 'Move this widget to the Trash?';
localizedStrings['OK'] = 'OK';
localizedStrings['Cancel'] = 'Cancel';

/**
 This item should currently only be localized for Japan. That is becuase
 we havea separate download page for Apple Japan only. Here is the Japanese string:
 http://www.apple.com/jp/downloads/dashboard/
 */
localizedStrings['http://www.apple.com/macosx/dashboard/'] = 'http://www.apple.com/macosx/dashboard/';
